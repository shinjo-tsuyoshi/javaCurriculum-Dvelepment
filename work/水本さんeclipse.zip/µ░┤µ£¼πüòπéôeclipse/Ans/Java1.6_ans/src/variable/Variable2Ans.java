package variable;

public class Variable2Ans {
	public static void main(String[] args) {
//		問１）
//		変数 x を宣言し、「3」を代入して下さい。
//		変数 x に自己代入を使って「20」を掛け算して下さい。
//		その後 x の値をコンソールに表示して下さい。
		int x = 3;
		x = x * 20;
		System.out.println(x);

//		問２）
//		以下のプログラムを作成してください。
//		①int 型の変数 i に 100 を代入する。
//		②インクリメント演算子を適用して数値を 1 増やす。
//		③コンソールに変数 i の値を表示する。
//		④デクリメント演算子を適用して数値を 1 減らす。
//		⑤コンソールに変数 i の値を表示する。
		int i = 100;
		i++;
		System.out.println(i);
		i--;
		System.out.println(i);

//		問３）
//		以下のプログラムを作成してください。
//		  ①画面に「あなたの年齢を予想します。」と表示する。
//		  ② 0 から 99 までの乱数を生成し、int型変数 expect に代入する。
//		    乱数の生成方法【例:int r = new java.util.Random().nextInt(◎);】
//		    ◎には発生させる乱数の上限値(指定値自体の数値は含まない)を入れる。
//		  ③ expect の数値をインクリメント演算子で 1 増やし、 1 から 100 の乱数に変更する。
//		  ④画面に「あなたの年齢はおそらく（乱数）歳ですね？」と表示します。
//		  ※実行するごとに年齢が変わるので、やってみてください。
		System.out.println("あなたの年齢を予想します。");
		int expect = new java.util.Random().nextInt(100);
		expect++;
		System.out.println("あなたの年齢はおそらく" + expect + "歳ですね？");

	}
}
